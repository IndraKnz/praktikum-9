vue
<template>
<div>
<h1>Tentang Kami</h1>
<p>PT GIT Solution adalah perusahaan teknologi yang
menyediakan solusi IT terbaik untuk berbagai bisnis.</p>
</div>
</template>
<script>
export default {
name: 'About'
}
</script>