vue
<template>
<div>
<h1>Layanan Kami</h1>
<ul>
<li>Pengembangan Software</li>
<li>Konsultasi IT</li>
<li>Manajemen Proyek</li>
</ul>
</div>
</template>
<script>
export default {
name: 'Services'
}
</script>